package com.techelevator.dao;

public interface SongGenreDao {
}
