package com.techelevator.dao;

public interface DjLibraryDao {
}
